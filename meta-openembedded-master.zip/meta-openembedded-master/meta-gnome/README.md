Dependencies
------------
This layer depends on:

URI: git://git.openembedded.org/openembedded-core
branch: master

URI: git://git.openembedded.org/meta-openembedded
branch: master

Send pull requests to openembedded-devel@lists.openembedded.org with '[meta-gnome]' in the subject'

When sending single patches, please using something like:
git send-email -M -1 --to openembedded-devel@lists.openembedded.org --subject-prefix='meta-gnome][PATCH'

Layer maintainer: Andreas Müller <schnitzeltony@gmail.com>
