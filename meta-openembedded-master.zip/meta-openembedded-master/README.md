Collection of layers for the OE-core universe

Main layer maintainer: Khem Raj <raj.khem@gmail.com>

This repository is a collection of layers to suppliment OE-Core
with additional packages, Each layer have designated maintainer
Please see the respective READMEs in the layer subdirectories
